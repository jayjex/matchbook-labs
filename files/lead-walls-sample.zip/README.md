# Dark Wallpaper Pack Vol.3 — Free Sample: 2 Wallpapers

Two full wallpapers from Vol.3 of the dark wallpaper pack, downscaled from 4K to 1920x1080. Try them on your actual desktop before buying the pack.

## What's in the sample

- `wall-01.png` — bioluminescent cave: glowing blue fungi on wet rock, dark underground lake
- `wall-19.png` — retro terminal: soft green scanlines, barrel distortion glow, dark edges

Both are 1920x1080 PNGs, identical to the 4K originals except for resolution.

## What's cut from the sample

- 18 more wallpapers (the full pack has 20)
- 4K resolution: the pack is 3840x2160, generated at 1920x1080 and Lanczos-upscaled — dark, low-detail art hides the upscale softness
- The other three themes: deep space nebulae, brutalist monochrome architecture, and amber CRT scanlines

Every wall in the pack keeps the center quiet so desktop icons and text stay readable, and all 20 were checked for brightness: dark overall, glow at the edges.

## Full version

Dark Wallpaper Pack Vol.3 — 20 wallpapers, 4K, personal and commercial use — is on the store: https://www.getly.store
