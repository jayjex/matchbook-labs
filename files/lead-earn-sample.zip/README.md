# Superteam Earn — Free Sample: 5 Live Listings

Five real listings pulled from the live superteam.fun API on 2026-09-04. This is a cut-down slice of the full dataset so you can inspect the data shape before buying anything.

## What's in the sample

`sample.csv` — 5 open bounties/projects with one row each:

- title, type (bounty / project), reward amount and token
- reward range (min/max ask) for project listings
- deadline, status, agent access flag
- sponsor name, comment and submission counts, slug

## What's cut from the sample

- 23 more listings (the full file has 28)
- Full description HTML for every listing
- `earn-api-endpoints.txt` — 186+ reverse-engineered API routes covering listings, comments, submissions, and sponsor dashboard operations
- The `/api/search/{title}` trick that pulls full description text from an undocumented endpoint

## Full version

The complete dataset ($49) is at https://www.getly.store/product/superteam-earn-28-live-listings-dataset-186-reverse-engineered-api-routes-mtmy11ny — 28 listings with full descriptions, the 186-route API map, and Privy auth flow notes.

Use cases: bounty aggregators, agent tooling, market research, notification bots.
